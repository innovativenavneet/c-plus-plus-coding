#include<iostream>
using namespace std;
//int z=3;
int main(){
    int a,b,c;
    cout<<"\nenter the value of a ";
    cin>>a;
    cout<<"\nenter the value of b ";
    cin>>b;
    c = a + b;
    cout<<"\nthe sum is "<<c;
    
    
    
cout<<"\nvalue of global variable is "<<::z;?

return 0;
}