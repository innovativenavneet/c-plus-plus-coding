#include<iostream>
using namespace std;
int
main ()
{
  int a = 4, b = 5;
  cout << "\nusing arthmetic operator";
  cout << "\nthe value of a + b is " << a + b;
  cout << "\nthe value of a -b is " << a - b ;
  cout << "\nthe value of a * b is " << a * b ;
  cout << "\nthe value of a / b is " << a / b ;
  cout << "\nthe value of a % b is " << a % b ;
  cout << "\nthe value of  a++ is " << a++ ;
  cout << "\nthe value of  a-- is " << a-- ;
  cout << "\nthe value of  ++a is " << ++a ;
  cout << "\nthe value of  --a is " << --a ;


  return 0;
}
