#include<iostream>
using namespace std;
int main(){
int a= 4;
float b = 777777777.888f;
long double c = 666.88;
cout<<"\nsize of b is "<<sizeof(b);
cout<<"\nsize of c is "<<sizeof(c);
    return 0;
}