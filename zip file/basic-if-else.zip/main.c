#include<stdio.h>
int main(){
    int a;
    printf("enter a  \n");
    scanf("%d", &a);
    (a>10) ? printf("a is greater than 10") : printf("a is less than 10");
}